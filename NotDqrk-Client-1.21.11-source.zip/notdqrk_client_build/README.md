# NotDqrk Client (Fabric 1.21.11)

A client-side visual enhancement mod for Minecraft Java Edition 1.21.11.

## Features

- Open the visuals menu with **Right Shift**.
- Animated sky overlays: Aurora, Nebula, Sunset, Storm and Starfield.
- Optional colour tint and grayscale overlay.
- HUD watermark, FPS counter and coordinates, with three display styles.
- Client-side sparkles, snowfall and shooting-star effects.
- Particle-based wing, halo and cape-style cosmetics (visible locally; these are particle effects, not server-synced wearable items).
- Colour themes and per-module settings.
- Settings are saved to `config/notdqrk-client.properties`.

## Requirements

- Minecraft Java **1.21.11**
- Java **21**
- Fabric Loader **0.20.1 or newer**
- Fabric API for 1.21.11

## Build

On a machine with internet access and Java 21 installed:

```bash
./gradlew build
```

On Windows, run `gradlew.bat build`. The remapped mod JAR will be in `build/libs/`.

## Install

1. Install Fabric Loader for Minecraft 1.21.11.
2. Install the matching Fabric API.
3. Put the built `notdqrk-client-1.0.0.jar` from `build/libs/` into your Minecraft `mods` folder.
4. Launch the Fabric 1.21.11 profile and press **Right Shift** in-game.

## Notes

This is a client-side visual mod. Particle cosmetics are rendered only on the local client and do not grant gameplay abilities or create server-side cosmetics. The project must be compiled against the declared Fabric/Minecraft dependencies before the JAR can be used.
